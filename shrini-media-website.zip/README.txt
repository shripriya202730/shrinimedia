SHRINI MEDIA WEBSITE — FIRST DRAFT

Keep index.html, style.css, script.js and the assets folder together.
To publish free with GitHub Pages:
1. Create a public GitHub repository named shrinimedia.
2. Upload the contents of this folder to the repository root.
3. Open Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. GitHub will display your live website address after deployment.

Review service descriptions and portfolio wording before launch. The portfolio section is intentionally marked as in progress.
